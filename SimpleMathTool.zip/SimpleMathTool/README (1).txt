JARVIS BACKUP v1.1 - 10-04-2025 13:32:38

Deze map bevat een volledige backup van het Jarvis systeem.
Alle bestanden zijn in hun originele staat opgeslagen en kunnen direct 
in een nieuw project worden geplaatst.

Inhoud:
- Python backend bestanden (*.py)
- HTML templates (templates/*.html)
- Static bestanden (CSS, JS, etc.)
- Database gegevens (database_data.json)

Voor automatische import van de database:
1. Plaats het complete backupbestand in de 'backups' map van je nieuwe Jarvis project
2. Start de applicatie - de gegevens worden automatisch geïmporteerd bij de eerste start
